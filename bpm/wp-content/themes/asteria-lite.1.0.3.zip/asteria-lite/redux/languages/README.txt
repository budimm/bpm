~~ IMPORTANT ~~

We need your help! We'll gladly accept any translation you can provide.

Just one suggestion, when running an update/translation please move the `~/sample` directory out of the root ReduxFramework plugin. We don't want to dirty our translation with a bunch of demo strings.

To add a translation, do a pull request from the repo: https://github.com/ReduxFramework/ReduxFramework

If you can't figure out a pull request, just post an issue with the file and we'll take care of it.

Thank you!


——————————————————————————

Special thanks to the following people for language translations

German [de_DE] @Abu-Taymiyyah
Bahasa Indonesia [id_ID] @riesurya
Tirnovanuaurel [IT_it] [RO_ro] @tirnovanuaurel