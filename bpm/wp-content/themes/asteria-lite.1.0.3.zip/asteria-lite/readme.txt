The theme is licensed Under GNU GPL v2

The images slide1.jpg , slide2.jpg & slide3.jpg in the "images" folder are Public domain images.

Image credit links:
slide1.jpg - http://pixabay.com/en/computer-computers-keyboard-313840/
slide2.jpg - http://pixabay.com/en/write-plan-business-startup-593333/
slide3.jpg - http://www.gratisography.com/



All other graphics used in this theme is desgined by me and licensed under GNU GPL v2


Limitations: 

#The top menu space is limited. If you assign lots of menu item to the menu position it may break.
# IE6, IE7, IE8 is not compatible. 


License Credits
---------------
jQuery FancyBox
http://fancybox.net/
Licensed under both MIT and GPL licenses

jQuery Nivo Slider
http://nivo.dev7studios.com
Licensed under the MIT license.

hoverIntent
http://cherne.net/brian/resources/jquery.hoverIntent.html
Licensed under the MIT license.

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/
Open source under the BSD License. 

jQuery Waypoints
https://github.com/imakewebthings/jquery-waypoints/
Licensed under the MIT license.

Simple jQuery Equal Heights
Dual licensed under the MIT and GPL licenses.

Jquery Count Down Widget
Based On: http://webdesign.tutsplus.com/tutorials/complete-websites/adding-a-jquery-countdown-plugin-to-our-coming-soon-page/
licensed under the MIT license.

jQuery EasyTabs plugin
https://github.com/JangoSteve/jQuery-EasyTabs
Dual licensed under the MIT and GPL licenses

jQuery Lazy Load
http://www.appelsiini.net/projects/lazyload
Licensed under the MIT license

jQuery Color
http://github.com/jquery/jquery-color
Licensed under the MIT license.

Sidr - v1.1.1 - 2013-03-14
https://github.com/artberri/sidr
Licensed under the MIT license.

waitForImages
https://github.com/alexanderdickson/waitForImages
Licensed under the MIT licenses.

imagesLoaded
http://imagesloaded.desandro.com/
Licensed under the MIT license.

jQuery Cookie Plugin
https://github.com/carhartl/jquery-cookie
Licensed under the MIT license.