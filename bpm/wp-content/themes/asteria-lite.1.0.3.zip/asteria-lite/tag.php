<?php get_header(); ?>
<?php global $asteria;?>
<!--Tag Posts-->
<div class="fixed_site">
	<div class="fixed_wrap">
		<?php get_template_part('layout'.$asteria['cat_layout_id'].''); ?>
	</div>
</div>
<?php get_footer(); ?>