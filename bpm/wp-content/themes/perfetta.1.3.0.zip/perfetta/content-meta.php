<?php
	/*
		Template for the content meta
	*/
?>
<aside class="post-meta">
	<?php perfetta_meta(); ?>
</aside><!-- .entry-meta -->