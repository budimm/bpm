<?php
/**
 * Admin "Welcome" page content component
 *
 * Footer.
 *
 * @package    Auberge
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    2.2.0
 * @version  2.2.0
 */





?>

</div> <!-- /.welcome-content -->

<p><small><em><?php esc_html_e( 'You can disable this page in Appearance &raquo; Customize &raquo; Theme Options &raquo; Others.', 'auberge' ); ?></em></small></p>
