		  	<?php do_action('get_footer');
		  	get_template_part('templates/footer'); ?>
		</div><!--Wrapper-->
	</body>
</html>
