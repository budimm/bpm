<?php
get_template_part( 'cfg/cfgs' );
get_template_part( 'cfg/default' );
get_template_part( 'cfg/pages' );
get_template_part( 'cfg/widgets' );
?>