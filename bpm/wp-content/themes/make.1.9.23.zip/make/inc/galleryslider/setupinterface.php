<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_GallerySlider_SetupInterface
 *
 * @since 1.7.0.
 */
interface MAKE_GallerySlider_SetupInterface extends MAKE_Util_ModulesInterface {}