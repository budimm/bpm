<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Setup_L10nInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Setup_L10nInterface {}