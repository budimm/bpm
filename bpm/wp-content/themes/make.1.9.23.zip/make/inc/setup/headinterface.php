<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Setup_HeadInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Setup_HeadInterface extends MAKE_Util_ModulesInterface {}