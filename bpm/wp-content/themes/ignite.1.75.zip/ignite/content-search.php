<div class="excerpt">
	<div class='excerpt-header'>
		<h2 class='excerpt-title'>
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>
	</div>
	<div class='excerpt-content'>
		<article>
			<?php ct_ignite_excerpt(); ?>
		</article>
	</div>
</div>